<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <div class="box-header">
            <h3 class="box-title">Clientes/Proveedores</h3>
          </div>
          <!-- /.box-header -->
          <div class="box-body">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
              <tr>
                <th>Nombre</th>
                <th></th>
              </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $giros_empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $giro_empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($giro_empresa->titulo); ?></td>
                    <td>
                        <a class="btn btn-success btn-sm" href="<?php echo e(route('alta-venta',['id'=>$giro_empresa->id])); ?>">
                            <i class="fa fa-eye"></i> Venta
                        </a>
                        <a class="btn btn-success btn-sm" href="<?php echo e(route('datos-clientes-proveedores',['id'=>$giro_empresa->id])); ?>">
                            <i class="fa fa-eye"></i> Ver
                        </a>
                        <a class="btn btn-primary btn-sm">
                            <i class="fa fa-edit"></i> Editar
                        </a>
                        <a class="btn btn-danger btn-sm">
                            <i class="fa fa-ban"></i> Bloquear
                        </a>
                    </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inven\inventario\resources\views/giros_empresas/ver.blade.php ENDPATH**/ ?>