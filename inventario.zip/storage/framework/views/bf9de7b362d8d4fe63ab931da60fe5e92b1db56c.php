<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <div class="box-header">
            <h3 class="box-title">Clientes/Proveedores</h3>
          </div>
          <!-- /.box-header -->
          <div class="box-body">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
              <tr>
                <th>Nombre</th>
                <th>Razon Social</th>
                <th>Telefono</th>
                <th>Correo</th>
                <th>Tipo</th>
                <th></th>
              </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $clientes_proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente_proveedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($cliente_proveedor->nombre); ?></td>
                    <td><?php echo e($cliente_proveedor->razon_social); ?></td>
                    <td><?php echo e($cliente_proveedor->telefono); ?></td>
                    <td><?php echo e($cliente_proveedor->correo); ?></td>
                    <td>
                        <?php switch($cliente_proveedor->tipo):
                            case (1): ?>
                                <?php echo e('Cliente'); ?>

                                <?php break; ?>
                            <?php case (2): ?>
                                <?php echo e('Proveedor'); ?>

                                <?php break; ?>
                            <?php case (3): ?>
                                <?php echo e('Cliente - Proveedor'); ?>

                                <?php break; ?>
                            <?php default: ?>
                                
                        <?php endswitch; ?>
                    </td>
                    <td>
                        <a class="btn btn-success btn-sm" href="<?php echo e(route('datos-clientes-proveedores',['id'=>$cliente_proveedor->id])); ?>">
                            <i class="fa fa-eye"></i> Ver
                        </a>
                        <a class="btn btn-primary btn-sm">
                            <i class="fa fa-edit"></i> Editar
                        </a>
                        <a class="btn btn-danger btn-sm">
                            <i class="fa fa-ban"></i> Bloquear
                        </a>
                    </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inven\inventario\resources\views/clientes_proveedores/ver.blade.php ENDPATH**/ ?>