<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <div class="box-header">
            <h3 class="box-title">Clientes/Proveedores</h3>
          </div>
          <!-- /.box-header -->
          <div class="box-body">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
              <tr>
                <th>Id Venta</th>
                <th>Cliente</th>
                <th>Pago</th>
                <th>Fecha</th>
                <th></th>
              </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($pago->venta_id); ?></td>
                    <td><?php echo e($pago->venta->clienteProvedor->razon_social); ?></td>
                    <td>$<?php echo e($pago->pago_con_iva); ?></td>
                    <td><?php echo e($pago->created_at); ?></td>
                    <th>
                        <a class="btn btn-success btn-sm" href="<?php echo e(route("ver-venta",['id'=> $pago->venta_id])); ?>">
                            <i class="fa fa-eye"></i> Ver Venta
                        </a>
                    </th>   
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inven\inventario\resources\views/pagos/ver.blade.php ENDPATH**/ ?>