<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
      <!-- left column -->
      <div class="col-md-6">
        <!-- general form elements -->
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Alta Folios</h3>
          </div>
          <div class="col-12">
            <?php if(Session::get('message')): ?>
              <div class="alert alert-danger">
                <?php echo e(Session::get('message')); ?>

              </div>
            <?php endif; ?>
          </div>
          <!-- /.box-header -->
          <!-- form start -->
          <form role="form" action="<?php echo e(route("save-folios")); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <div class="box-body">
              <div class="form-group">
                <label for="exampleInputEmail1">Folio</label>
                <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Folio" name="folio" required>
                <input type="hidden" name="vendido" value="0">
              </div>
            </div>
            <!-- /.box-body -->

            <div class="box-footer">
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
          </form>
        </div>

      </div>
    </div>
    <!-- /.row -->
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inven\inventario\resources\views/folios/alta.blade.php ENDPATH**/ ?>