<?php use App\Http\Controllers\ClienteProveedorController; ?>


<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <div class="box-header">
            <h3 class="box-title">Clientes/Proveedores</h3>
          </div>
          <!-- /.box-header -->
          <div class="col-6">
            <div class="box-body">

                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>id</th>
                    <th>Fecha y hora</th>
                    <th>Total</th>
                    <th>Pagado</th>
                    <th>Falta x pagar</th>
                    <th>Fecha y hora ultimo pago</th>
                    <th>Status</th> 
                    <th></th>
                  </tr>
                  </thead>
                  <tbody>
                        <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <?php
                              $pago = ClienteProveedorController::seleccionarPagos($venta->id);
                              $falta_por_pagar = $venta->total_con_iva - $pago[0]['total_actual_con_iva']
                          ?>
                            <td><?php echo e($venta->id); ?></td>
                            <td><?php echo e($venta->created_at); ?></td>
                            <th><?php echo e($venta->total_con_iva); ?></th>
                            <th>$<?php echo e($falta_por_pagar); ?></th>
                            <th>$<?php echo e($pago[0]['total_actual_con_iva']); ?></th>
                            <th><?php echo e($pago[0]['created_at']); ?></th>
                            <th>
                              <?php if($falta_por_pagar<=0): ?>
                                <small class="label bg-green">Pagado</small>
                              <?php else: ?>
                                <small class="label bg-red">Pendiente de pago</small>
                              <?php endif; ?>
                            </th>
                            <th>
                                <a class="btn btn-primary btn-sm" href="<?php echo e(route("ver-venta",['id'=> $venta->id])); ?>">
                                    <i class="fa fa-eye"></i> Ver
                                </a>
                            </th>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
            </div>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inven\inventario\resources\views/clientes_proveedores/info.blade.php ENDPATH**/ ?>